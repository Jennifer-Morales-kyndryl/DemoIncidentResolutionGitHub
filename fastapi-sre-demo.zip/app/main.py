"""
Servicio de Transacciones — API de ejemplo para la demo de SRE.

Simula un servicio de procesamiento de pagos. Bajo el modo de fallo
correcto (FAULT_MODE=pool_leak), se degrada con latencia alta y errores,
reproduciendo el escenario de "connection pool exhaustion" de la propuesta.
"""

import os
import time
from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.database import get_db, init_db, FAULT_MODE

app = FastAPI(
    title="Servicio de Transacciones",
    description="API de procesamiento de pagos (demo SRE)",
    version="1.0.0",
)


@app.on_event("startup")
def startup():
    """Al arrancar, prepara la base de datos."""
    init_db()


@app.get("/")
def root():
    """Endpoint de bienvenida. Muestra el modo de fallo activo."""
    return {
        "service": "Servicio de Transacciones",
        "status": "online",
        "fault_mode": FAULT_MODE,
    }


@app.get("/health")
def health():
    """Endpoint de salud para monitoreo."""
    return {"status": "healthy"}


@app.get("/transactions")
def list_transactions(db: Session = Depends(get_db)):
    """
    Lista las transacciones. Este es el endpoint que se degrada
    cuando el pool de conexiones se agota.
    """
    start = time.time()
    result = db.execute(
        text("SELECT id, amount, status, created_at "
             "FROM transactions ORDER BY id LIMIT 20")
    )
    rows = [
        {
            "id": r[0],
            "amount": float(r[1]),
            "status": r[2],
            "created_at": str(r[3]),
        }
        for r in result
    ]
    elapsed_ms = round((time.time() - start) * 1000, 1)
    return {"count": len(rows), "elapsed_ms": elapsed_ms, "transactions": rows}


@app.get("/transactions/{transaction_id}")
def get_transaction(transaction_id: int, db: Session = Depends(get_db)):
    """Obtiene una transacción por su id."""
    result = db.execute(
        text("SELECT id, amount, status, created_at "
             "FROM transactions WHERE id = :id"),
        {"id": transaction_id},
    )
    row = result.first()
    if row is None:
        raise HTTPException(status_code=404, detail="Transacción no encontrada")
    return {
        "id": row[0],
        "amount": float(row[1]),
        "status": row[2],
        "created_at": str(row[3]),
    }
