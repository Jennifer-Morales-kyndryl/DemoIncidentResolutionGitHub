"""
Configuración compartida de pytest.

El fixture autouse asegura que la tabla exista antes de correr las
pruebas, ya que el TestClient no siempre dispara el evento de startup.
"""

import pytest
from app.database import init_db


@pytest.fixture(autouse=True, scope="session")
def preparar_base_de_datos():
    """Crea la tabla y los datos de ejemplo una vez antes de las pruebas."""
    init_db()
    yield
