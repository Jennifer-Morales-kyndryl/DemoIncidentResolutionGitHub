"""
Pruebas para el Servicio de Transacciones.

Estas pruebas cumplen dos propósitos en la demo:
  1. Validar que la app funciona correctamente (endpoints responden bien).
  2. Servir como la "validación automática" que Copilot ejecuta tras
     proponer la corrección del bug de connection pool.

La prueba clave es `test_pool_no_se_agota_bajo_carga`: con el código correcto
pasa, y con el bug (FAULT_MODE=pool_leak) falla, demostrando que la
corrección funcionó.
"""

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_root_responde():
    """El endpoint raíz responde con estado online."""
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["status"] == "online"


def test_health_ok():
    """El endpoint de salud responde healthy."""
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"


def test_listar_transacciones():
    """El endpoint de transacciones devuelve una lista."""
    response = client.get("/transactions")
    assert response.status_code == 200
    data = response.json()
    assert "transactions" in data
    assert data["count"] > 0


def test_transaccion_no_encontrada():
    """Pedir una transacción inexistente devuelve 404."""
    response = client.get("/transactions/999999")
    assert response.status_code == 404


def test_pool_no_se_agota_bajo_carga():
    """
    Prueba de resiliencia: hacemos muchas peticiones seguidas.

    Con el código CORRECTO, todas responden 200 porque las conexiones
    se devuelven al pool.

    Con el BUG (pool_leak), el pool se agota y esta prueba falla por
    timeouts. Por eso es la prueba que 'verifica' la corrección.
    """
    codigos = []
    for _ in range(30):
        r = client.get("/transactions")
        codigos.append(r.status_code)

    # Todas las peticiones deben responder correctamente.
    assert all(c == 200 for c in codigos), (
        f"Algunas peticiones fallaron: {codigos}. "
        "Posible agotamiento del pool de conexiones."
    )
