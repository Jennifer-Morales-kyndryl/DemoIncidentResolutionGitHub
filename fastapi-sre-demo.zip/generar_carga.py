"""
Generador de carga para provocar el incidente en vivo.

Lanza muchas peticiones concurrentes al servicio. Con el código sano,
todas responden rápido. Con el bug (FAULT_MODE=pool_leak), el pool se
agota y verás latencias altas y errores/timeouts — justo el síntoma
de la demo.

Uso:
    python generar_carga.py
    python generar_carga.py --peticiones 100 --concurrencia 20
"""

import argparse
import concurrent.futures
import statistics
import time
import httpx

URL = "http://localhost:8000/transactions"


def una_peticion(_):
    """Hace una petición y devuelve (exito, latencia_ms)."""
    inicio = time.time()
    try:
        r = httpx.get(URL, timeout=15.0)
        latencia = (time.time() - inicio) * 1000
        return (r.status_code == 200, latencia)
    except Exception:
        latencia = (time.time() - inicio) * 1000
        return (False, latencia)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--peticiones", type=int, default=60,
                        help="Número total de peticiones")
    parser.add_argument("--concurrencia", type=int, default=15,
                        help="Peticiones simultáneas")
    args = parser.parse_args()

    print(f"Lanzando {args.peticiones} peticiones "
          f"({args.concurrencia} concurrentes) a {URL}\n")

    inicio = time.time()
    with concurrent.futures.ThreadPoolExecutor(
        max_workers=args.concurrencia
    ) as executor:
        resultados = list(executor.map(una_peticion, range(args.peticiones)))
    total = time.time() - inicio

    exitos = sum(1 for ok, _ in resultados if ok)
    fallos = args.peticiones - exitos
    latencias = [lat for _, lat in resultados]

    print("=" * 50)
    print("RESULTADOS")
    print("=" * 50)
    print(f"  Exitosas:        {exitos}/{args.peticiones}")
    print(f"  Fallidas:        {fallos}/{args.peticiones}")
    print(f"  Tasa de error:   {round(fallos / args.peticiones * 100, 1)}%")
    print(f"  Latencia media:  {round(statistics.mean(latencias), 1)} ms")
    print(f"  Latencia máx:    {round(max(latencias), 1)} ms")
    print(f"  Tiempo total:    {round(total, 2)} s")
    print("=" * 50)

    if fallos > 0 or statistics.mean(latencias) > 3000:
        print("\n⚠️  INCIDENTE DETECTADO: el servicio está degradado.")
        print("   Síntomas compatibles con agotamiento del pool de conexiones.")
    else:
        print("\n✅  Servicio sano: todas las peticiones respondieron rápido.")


if __name__ == "__main__":
    main()
